

Below is the description of each file in this folder

createMask.m          ----- Matlab scripts to create mask image that identify the stop region
main.py               ----- Python scripts that implement the stop sign detection and localization functionalties
dataOperations.py     ----- Python scripts that provice some data operations functions for main.py such as creating training data set...
logisticModel.py      ----- Python scripts that define the logistic regression model and implement functionalities including training the model and testing
stop_sign_detector.py ----- Python scripts that used for testing on autograder