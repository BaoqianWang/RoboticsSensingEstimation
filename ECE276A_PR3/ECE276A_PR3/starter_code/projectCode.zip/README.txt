UCSD ECE 276A Sensing&Estimation in Robotics
Project 3: Visual Inertial SLAM
Baoqian Wang

File Description:

	1. utils.py:  Implement some auxiliary functions for visual inertial slam including HatMap function, projective function
		      projective derivative function and so on.

	2. hw3_main.py: Implement EKF prediction (def predictionEKF()), EKF update (def updateEKF()) and EKF mapping (def mappingEKF()).
			Moreover, the Visual-Inertial SLAM is also implemented by combining the three functions together. 